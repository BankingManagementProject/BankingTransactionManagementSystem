import {describe,it,expect} from 'vitest';
function lockAfterFive(failed:number){return failed>=5}
describe('OBTS auth rules',()=>{it('locks after five failed login attempts',()=>{expect(lockAfterFive(4)).toBe(false);expect(lockAfterFive(5)).toBe(true)});it('accepts 4 to 6 digit transaction PINs',()=>{expect(/^\d{4,6}$/.test('1234')).toBe(true);expect(/^\d{4,6}$/.test('123')).toBe(false);expect(/^\d{4,6}$/.test('1234567')).toBe(false)})});
