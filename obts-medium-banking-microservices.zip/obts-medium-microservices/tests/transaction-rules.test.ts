import {describe,it,expect} from 'vitest';
function withinDailyLimit(already:number,next:number,limit=50000){return already+next<=limit}
function savingsBalanceValid(balance:number,amount:number,min=1000){return balance-amount>=min}
describe('OBTS transaction validation rules',()=>{it('allows transfers at daily limit but blocks above it',()=>{expect(withinDailyLimit(40000,10000)).toBe(true);expect(withinDailyLimit(40000,10001)).toBe(false)});it('preserves savings minimum balance',()=>{expect(savingsBalanceValid(5000,4000)).toBe(true);expect(savingsBalanceValid(5000,4001)).toBe(false)});it('keeps rejected add-money requests from implying a credit',()=>{const status='REJECTED';expect(status==='APPROVED').toBe(false)})});
