# OBTS medium microservices architecture

```text
React + TypeScript + Tailwind (localhost:5173)
                 |
          API Gateway :4000
  JWT checks for /admin + rate limiting
                 |
   +------+------+------+------+------+
   |      |      |      |      |      |
 Auth   User  Account Transaction Admin Notification
 :4001 :4002  :4003   :4004       :4005 :4006
   |      |      |      |      |      |
   +------+------+- PostgreSQL -+-----+
             schemas: auth, users, accounts,
             transactions, admin, notifications
        Redis (OTP)     RabbitMQ (domain events)
```

Each service has its own process, port, folder, health endpoint and data schema. For a college-scale project the schemas share one local PostgreSQL instance to reduce resource use. Transaction and add-money approval use PostgreSQL transactions and row locks. In a production multi-database architecture, cross-service money movement requires an outbox/Saga protocol rather than one shared SQL transaction.

## Transfer status timeline
`PENDING → VALIDATING → DEBITING → CREDITING → SUCCESS`

Simulated credit failure: `PENDING → VALIDATING → DEBITING → COMPENSATING → COMPENSATED`. The source balance is restored and both ledger entries are recorded. Validation/limit failures return a reason and do not debit. Add-money requests have their own `PENDING → APPROVED | REJECTED` workflow; only approval credits the account.
