# Transaction status model

- PENDING: request accepted for processing.
- VALIDATING: account state, PIN, available balance and daily cumulative transfer amount are checked.
- DEBITING: source account is debited and a debit ledger entry is inserted.
- CREDITING: destination is credited and credit ledger entry inserted.
- SUCCESS: both ledger entries committed.
- FAILED: validation or processing failed; API returns the failure reason.
- COMPENSATING: destination credit simulation fails after source debit; the source is credited back.
- COMPENSATED: refund and compensation ledger entry committed.
- ESCALATED: documented SRS state reserved for a failed compensation/manual intervention extension.

For the demo, use the Transfer page checkbox `Simulate destination-credit failure` to see COMPENSATING and COMPENSATED. For real DB/connection failures the SQL transaction rolls back atomically, so no partial debit remains. The daily limit is configured with `DAILY_TRANSFER_LIMIT` (default ₹50,000). Rejections of add-money requests include the admin reason and do not change balance.
