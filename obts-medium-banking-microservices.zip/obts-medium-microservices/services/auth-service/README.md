# auth-service

Port: 4001. Health endpoint: `/health`. Runs as a separate local container using the root Dockerfile and root dependency manifest. Data ownership schema: auth. API route prefix is available through the API Gateway at `http://localhost:4000`. See the root README and docs for local test steps.
