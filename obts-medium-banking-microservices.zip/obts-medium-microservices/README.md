# Online Banking Transaction System (OBTS) — medium college project

A local-only React + TypeScript frontend and Express + TypeScript microservices project based on the uploaded OBTS SRS. It demonstrates role-based access, account management, daily transfer limits, transaction history, and status tracking with compensation. This is a simulation for academic demonstration, not real banking software.

## Architecture
See [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md) and [`docs/TRANSACTION_WORKFLOW.md`](docs/TRANSACTION_WORKFLOW.md). The gateway is port 4000; auth/user/account/transaction/admin/notification services use ports 4001–4006. PostgreSQL has a schema per service (`auth`, `users`, `accounts`, `transactions`, `admin`, `notifications`) in one local instance. Redis stores OTPs; RabbitMQ carries domain events.

## Requirements
- Docker Desktop running on Windows/macOS/Linux
- At least 4 GB free RAM recommended
- No separate Node/Postgres/Redis/RabbitMQ installation needed for Docker mode

## Run on Windows
1. Extract this ZIP into a new folder.
2. Copy `.env.example` to `.env` in the project root (same level as `docker-compose.yml`).
3. Change `POSTGRES_PASSWORD`, `RABBITMQ_DEFAULT_PASS`, `JWT_SECRET`, `JWT_REFRESH_SECRET`, and `INITIAL_ADMIN_PASSWORD` before use.
4. From that root folder run:

   ```powershell
   docker compose config
   docker compose up --build -d
   docker compose ps
   ```
5. Open `http://localhost:5173`. API gateway health: `http://localhost:4000/health`; docs route map: `http://localhost:4000/docs`; RabbitMQ UI: `http://localhost:15672`.
6. Seed the administrator with `docker compose exec api-gateway npx tsx scripts/seed.ts`. Default admin email is `admin@obts.local`; password is the `INITIAL_ADMIN_PASSWORD` value in `.env` (default `ChangeThisAdminPassword123!`).
7. Optional: seed three sample customers, balances and sample transaction history with `docker compose exec api-gateway npx tsx scripts/seed-demo.ts`. Sample users use `user1@obts.local`, `user2@obts.local`, `user3@obts.local`, each with password `DemoUser123!`.
8. Register a user, submit KYC, sign out, log in as admin, approve KYC, return to customer session, set a transaction PIN, and use the admin portal to approve/reject add-money requests. Transfers require active accounts and PIN.

## Sample workflow
1. Register a customer at the frontend.
2. Sign in, open Profile & KYC and submit ID type, ID number, date of birth and address. Only a masked ID suffix is stored/displayed.
3. Sign in as admin; KYC Review → Approve. This sets user status ACTIVE.
4. Admin KYC approval automatically creates a first zero-balance savings account if the customer does not already have one. After verification, the customer can request an additional account.
5. Add Money → submit a request. The balance remains unchanged while PENDING.
6. Admin → Add Money Requests → Approve. The account balance increases and an ADD_MONEY transaction and credit ledger entry are created. Rejecting instead stores a reason and does not credit.
7. Set a transaction PIN in Profile & KYC, add a beneficiary, and submit a transfer to an active destination account. The request remains `PENDING_ADMIN_APPROVAL`; the source balance is unchanged.
8. Admin → Pending Transfers → Approve or Reject. Approval runs the balance/limit checks and records DEBITING/CREDITING/SUCCESS. Rejection records REJECTED and a reason without moving money.
9. To demonstrate compensation, tick “Simulate destination-credit failure” before submitting. When the admin approves, the source is debited, the simulated destination credit fails, and the application records COMPENSATING/COMPENSATED while restoring the source balance.

## Local development API notes
The frontend uses relative `/api` routes, but Nginx currently needs a proxy to gateway. For direct frontend development, create `frontend/.env.local` with `VITE_API_BASE_URL=http://localhost:4000` only if you change `frontend/src/App.tsx` to use that variable. In the provided Docker setup the Nginx config proxies `/api` to `api-gateway:4000`.

Set transaction PIN:
```powershell
$token = "PASTE_ACCESS_TOKEN"
Invoke-RestMethod -Method Post -Uri http://localhost:4000/auth/pin -Headers @{Authorization="Bearer $token"} -ContentType "application/json" -Body '{"pin":"1234"}'
```

## Google OAuth and SMS
- Google OAuth: the auth service implements the OAuth authorization-code redirect and callback. Add `GOOGLE_CLIENT_ID` and `GOOGLE_CLIENT_SECRET` to `.env`, and register `http://localhost:4001/auth/google/callback` as an authorized redirect URI in Google Cloud Console. Without credentials, the route returns a configuration message.
- OTP: set `SMS_PROVIDER=console`; a local OTP is printed in `docker compose logs -f auth-service`. OTPs expire in 5 minutes, allow 3 attempts and have a 30-second resend cooldown. For real SMS, configure `SMS_PROVIDER=twilio` and the Twilio credentials.
- RabbitMQ events are published for core events and the notification consumer stores in-app notifications. If SMTP credentials are set, the consumer attempts email alerts; with Twilio configured, it attempts SMS alerts. Provider delivery depends on valid credentials and recipient/provider requirements.

## Tests and troubleshooting
- `docker compose logs -f api-gateway auth-service transaction-service admin-service notification-service`
- `docker compose ps`
- `docker compose down` stops containers and preserves data.
- `docker compose down -v` removes the local database volume permanently. Only do this if you want a completely fresh database.
- If images fail to download, retry `docker compose up --build` after Docker Desktop network access is restored.

## Important project limitations
- Balances and payments are simulated; no bank network or real money is involved.
- All services are separate processes but use schemas in one PostgreSQL instance so the local demo is manageable. Production distributed transfers need an outbox/Saga design and stronger operational controls.
- Google OAuth and Twilio SMS/email adapters are implemented but require valid provider credentials and were not end-to-end tested here. PDF statements, document upload/scanning, automatic FD/RD maturity and recurring debit scheduler, full fraud rules, and production-grade outbox/retry semantics are not implemented. CSV export is available in the UI.
- Docker first startup creates schemas but does not automatically insert an admin. Run `docker compose exec api-gateway npx tsx scripts/seed.ts` after the containers are healthy. To add sample customers and balances, run `docker compose exec api-gateway npx tsx scripts/seed-demo.ts`.
- Never use real passwords, bank credentials, or real personal documents in this academic demo.
